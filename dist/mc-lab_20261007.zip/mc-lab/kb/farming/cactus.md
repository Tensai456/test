# กระบองเพชร

<!-- สร้างอัตโนมัติโดย scripts/split_kb.mjs จาก docs/wiki/farming.md · ห้ามแก้มือ -->
> W = https://minecraft.wiki/w/ (อ้างเป็น W/ชื่อหน้า) · ตัวเลขทุกตัวมาจากสรุป search ของ minecraft.wiki; ไม่ทราบ = [ไม่แน่ใจ]

| รายการ | ค่า | แหล่ง |
|---|---|---|
| สูงสุด | 3 block (ต่อ 16 random tick) | W/Cactus |
| block ข้างเคียง | block ใดๆ ติดข้าง ทำให้ cactus หัก | W/Cactus |
| ทรายตกทับ | กลายเป็นไอเทม ไม่ทำลายต้น | W/Cactus |
| พื้นปลูกได้ | sand, red sand, suspicious sand หรือบน cactus อีกต้น | W/Cactus |

บอตควร: อย่าให้มี block ข้างต้น (เว้น 1 ช่องรอบ), เก็บ block ที่ 2–3; ระวังดาเมจจากการชน
ตัดสินผล: เกณฑ์แล็บ — ผ่านถ้าไม่ได้ดาเมจและเก็บได้ ≥1 ชิ้น/รอบ
